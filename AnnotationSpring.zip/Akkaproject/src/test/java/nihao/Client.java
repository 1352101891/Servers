package nihao;

import java.lang.reflect.Method;
import java.time.Duration;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.omg.CORBA.TIMEOUT;
import static java.util.concurrent.TimeUnit.SECONDS;  
import java.util.Random;  
import akka.actor.ActorRef;  
import akka.actor.ActorSystem;  
import akka.actor.Props;  
import com.typesafe.config.ConfigFactory;

import akka.actor.UntypedActor;
import calculate.add;
import calculate.muti;
import scala.concurrent.duration.FiniteDuration;
 

public class  Client {
 		 
		public static void main(String[] args) {  
		    if (args.length == 0 || args[0].equals("CalculatorWorker"))  
		      startRemoteWorkerSystem();  
		    if (args.length == 0 || args[0].equals("Creation"))  
		      startRemoteCreationSystem();  
		  }  
		  
		  public static void startRemoteWorkerSystem() {  
//		    ActorSystem.create("CalculatorWorkerSystem",  
//		        ConfigFactory.load(("worker")));  
//		    System.out.println("Started CalculatorWorkerSystem");  
		  }  
		  
		  public static void startRemoteCreationSystem() {  
		    final ActorSystem systemprocess = ActorSystem.create("CreationSystem",  
		        ConfigFactory.load("master"));  
		    final ActorRef actor = systemprocess.actorOf(Props.create(master.class),  
		        "creationActor");  
		  
		    System.out.println("Started CreationSystem");  
		    final Random r = new Random();  
//		    Class<?> clazz=Duration.class;
//		    Method method=clazz.getDeclaredMethod("create", new Class[] { long.class, int.class});
//		    method.setAccessible(true);
 
		    new Thread(new Runnable() {  
			    public void run() {  
		        	  while(true){
		        		  try {
							Thread.sleep(2000);
						  } catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
						  }
		        		  int size=r.nextInt(5);
		        		  for(int i=0;i<size;i++){
			        		  if (r.nextInt(100) % 2 == 0) {  
			        			  actor.tell(new add(r.nextInt(100), r.nextInt(100)), null);  
					          } else {  
					              actor.tell(new muti(r.nextInt(10000), r.nextInt(99) + 1),null);  
					          } 
		        		  }
		        	  }
		        }} 
		    ).start();
 	 }
}