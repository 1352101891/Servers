package nihao;

public class test {
	
	public static void main(String[] args){
		Longcompare(1L,1L);
		Intercompare(1,1);
	}
	
	static void Longcompare(Long a,Long b){
		System.out.println(a==b);
	}
	
	static void Intercompare(Integer a,Integer b){
		System.out.println(a==b);
	}
}
