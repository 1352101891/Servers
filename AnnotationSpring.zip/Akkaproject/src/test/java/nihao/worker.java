package nihao;

import akka.actor.UntypedActor;
import calculate.add;
import calculate.muti;

public class  worker extends UntypedActor {

	@Override
	public void onReceive(Object message) throws Exception {
		// TODO Auto-generated method stub
		if(message instanceof add){
			add a= (add) message;
			a.calculate();
			System.out.println("我是worker,"+a.getClass().getName()+"计算结果："+a.result);
			Thread.sleep(1000);
			getSender().tell(message, getSelf());
		} else if(message instanceof muti){
			muti a= (muti) message;
			a.calculate();
			System.out.println("我是worker,"+a.getClass().getName()+"计算结果："+a.result);
			getSender().tell(message, getSelf());
			Thread.sleep(1000);
		}
	}
 
}