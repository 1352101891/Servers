package nihao;

import java.util.HashMap;
import java.util.Map;
import akka.actor.ActorRef;
import akka.actor.Props;
import akka.actor.UntypedActor;
import akka.io.Tcp.Message;
import calculate.add;
import calculate.base;
import calculate.muti;
import scala.annotation.meta.setter;

public class master extends UntypedActor{
	private Map<ActorRef,ActorRef> map =new HashMap<ActorRef, ActorRef>(); 
	
	
	@Override
	public void onReceive(Object message) throws Exception {
		// TODO Auto-generated method stub
		base b=(base) message;
		if (b.cal) {
			ActorRef client=map.get(getSender());
//			client.tell(message, getSelf());
			map.remove(getSender());
			getContext().stop(getSender());
			System.out.println("我是master,结果是："+b.result+"\t，还有"+map.size()+"个工作者");
		}else {
			ActorRef worker=getContext().actorOf(Props.create(worker.class));
			worker.tell(message, getSelf());
			System.out.println("master把消息发送了");
			map.put(worker,getSender());
		}
 		 
	}

}
