package calculate;

import java.io.Serializable;

public class add extends base{
 
	public add(int a, int b) {
		super(b, b);
 	}
 
	public void calculate(){
		result=a+b;
		setCal(true);
	}

}
