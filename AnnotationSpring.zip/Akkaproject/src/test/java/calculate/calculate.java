package calculate;

public abstract class calculate {
    abstract void calculate();
}
