package calculate;

import java.io.Serializable;

public abstract class base  extends calculate implements Serializable{
	public int a;
	public int b;
	public int result;
	public boolean  cal=false;
	
	public base(int a, int b) {
		super();
		this.a = a;
		this.b = b;
	}
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}
	public int getB() {
		return b;
	}
	public void setB(int b) {
		this.b = b;
	}
	public int getResult() {
		return result;
	}
	public void setResult(int result) {
		this.result = result;
	}
	public boolean isCal() {
		return cal;
	}
	public void setCal(boolean cal) {
		this.cal = cal;
	}
 
	
 
 }
