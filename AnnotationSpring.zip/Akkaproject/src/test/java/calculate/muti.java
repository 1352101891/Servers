package calculate;

import java.io.Serializable;

public class muti extends base{
	 
	public muti(int a, int b) {
		super(b, b);
 	}
 
	public void calculate(){
		result=a+b;
		setCal(true);
	}
	
}
