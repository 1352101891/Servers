package anInterface;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * RUNTIME属性代表的是注解信息保留到运行时，
 * 这样运行之后可以通过反射获取。
 * @author ezqiulv
 * METHOD代表该注解只能注解方法
 */
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface Testmethod {
	String value() default "testmethod";
}
