package user;

public class person {

	private String name="吕秋";

	
	
	public person() {
		super();
	}

	public person(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
