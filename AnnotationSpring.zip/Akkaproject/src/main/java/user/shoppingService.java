package user;

import anInterface.MyResource;

public class shoppingService {
	private shop mShop;
	private person mPerson;
 
 	public shoppingService() {
		super();
	}
	public shoppingService(shop mShop, person mPerson) {
		super();
		this.mShop = mShop;
		this.mPerson = mPerson;
	}
	public shop getmShop() {
		return mShop;
	}
	
	@MyResource(value="shop")
	public void setmShop(shop mShop) {
		this.mShop = mShop;
	}
	public person getmPerson() {
		return mPerson;
	}
	
	@MyResource(value="person")
	public void setmPerson(person mPerson) {
		this.mPerson = mPerson;
	}
		
	
	public void service() {
		mShop.goshop(mPerson.getName());
	}
	
}
