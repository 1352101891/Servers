package user;

import anInterface.MyResource;
import anInterface.Test;
import anInterface.Testmethod;

@Test()
public class shop {
	private String  shopname="美特斯邦威";
	private String  shoploca="上海徐家汇";
 

	public shop() {
		super();
	}



	@Testmethod("gotoshop")
	public void goshop(String name){
		System.out.println("\n"+name+"is shopping! at"+shoploca+"的"+shopname+"\n");
	}

	
	
	public String getShopname() {
		return shopname;
	}


	public void setShopname(String shopname) {
		this.shopname = shopname;
	}


	public String getShoploca() {
		return shoploca;
	}

 
	public void setShoploca(String shoploca) {
		this.shoploca = shoploca;
	}

}
