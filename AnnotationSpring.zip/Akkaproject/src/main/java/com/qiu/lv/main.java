package com.qiu.lv;

 
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;

import anInterface.Test;
import anInterface.Testmethod;
import annotation.BeansManager;
import user.shop;
import user.shoppingService;

@Test("测试类")
public class main {
	
	@Testmethod("测试方法")
	public void test() {
		
	}
	
	public static void main(String[] args){

		/**	记得需要把所有需要注入的类都加上空参数的构造函数，要不然报错
		 *  at java.lang.Class.newInstance(Unknown Source)
		 *  如果path以"/"开头，例如："/a.txt"，则从classpath的根下获取资源；
		 *	如果path不以"/"开头，例如"a.txt"，则从类所在的包路径下取资源。
		 */
		BeansManager beansManager= BeansManager.getInstance("beans.xml");
		shoppingService service= (shoppingService) beansManager.getObject("shoppingService");	
		service.service();
 
		
		System.out.println("...............");
		System.out.println("...............");
		Test t = main.class.getAnnotation(Test.class);
		System.out.println(t.value());
		System.out.println(shop.class.getName());
		try {
			PropertyDescriptor[] propertyDescriptors= Introspector.getBeanInfo(shop.class).getPropertyDescriptors();
			for (PropertyDescriptor propertyDescriptor : propertyDescriptors) {
				System.out.println(propertyDescriptor.getName());
			}

		} catch (IntrospectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 	}
}
