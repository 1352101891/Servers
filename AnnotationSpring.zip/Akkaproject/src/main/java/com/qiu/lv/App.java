package com.qiu.lv;

import user.person;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        person sPerson=new person();
    }
}
