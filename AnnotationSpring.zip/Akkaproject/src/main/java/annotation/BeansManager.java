package annotation;
 
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import anInterface.MyResource;
import annotation.bean.BeanDefinition;
import annotation.bean.PropertyDefinition;

public class BeansManager {
	private String XMLname;
	private Map<String, Object> Beansmap =new HashMap<String, Object>();
	private Map<String,BeanDefinition> map;
	
	private static BeansManager beansmanager=null;
	
	public static BeansManager getInstance(String XMLname){
		if(beansmanager==null){
			synchronized (BeansManager.class) {			 
				beansmanager=new BeansManager(XMLname);
			}	
		} 
		return beansmanager;	
	}
	
	BeansManager(String XMLname){
		this.XMLname=XMLname;
		InitBeans(XMLname);
	}
	
	private void  InitBeans(String filename){
	 
		 map=XMLparse.read(filename);
		 InitObject();
		 injectObjectByXML();
		 injectObjectByAnnotation();
	}
	
	
 	private void InitObject() {
 		 Iterator<String> iterable=  map.keySet().iterator();
 		 BeanDefinition beanDefinition ;
		 while(iterable.hasNext()){
			 beanDefinition = map.get(iterable.next());
			 try {
				 
				 /**
				  * 记得给需要反射生成对象的类加上无参构造函数，要不然报错
				  * at java.lang.Class.newInstance(Unknown Source)
				  */
				 Object object =  BeansManager.class.getClassLoader().loadClass(beanDefinition.getClazz()).newInstance();
				
				Beansmap.put(beanDefinition.getId(), object);		
			 } catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			 }  catch (InstantiationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			 } catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			 }
		 }
	}
	
 	
 	/**
 	 * 通过XML内部的property属性注入
 	 */
	public void injectObjectByXML(){
		Iterator<String> iterator=map.keySet().iterator();
 		while (iterator.hasNext()) {
 			BeanDefinition  beanDefinition= map.get(iterator.next());
 			List<PropertyDefinition> proDens= beanDefinition.getPropertyDefinitions();
 			for (PropertyDefinition prodefine : proDens) {
 				if(Beansmap.containsKey(prodefine.getRef())){
 					Object injectobject= Beansmap.get(prodefine.getRef());
 					Object beInjectObject = Beansmap.get(beanDefinition.getId());
 					Field[] fields= beInjectObject.getClass().getDeclaredFields();
 					if (injectobject!=null) { //如果注入的bean存在
 						for (Field field : fields) {
  							if (field.getName().equals(prodefine.getName())) {
 								field.setAccessible(true);
 								try {
									field.set(beInjectObject, injectobject);
									break;
 								} catch (IllegalArgumentException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								} catch (IllegalAccessException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
 							}
 						}
					} 
  				}
			}
 		}
	}
 	
 	
 	
 	/**
 	 * 注解注入
 	 */
 	public void injectObjectByAnnotation(){
 		Iterator<String> iterator=Beansmap.keySet().iterator();
 		while (iterator.hasNext()) {
 			Object  object= Beansmap.get(iterator.next());
 			try {
 				
 				
 				/**	通过函数注解
 				 * 获取这个类的所有域的所有属性描述
 				 */
				PropertyDescriptor[] propertyDescriptors= Introspector.getBeanInfo(object.getClass()).getPropertyDescriptors();
				for(int i=0;i<propertyDescriptors.length;i++){
					Object injectBean=null;
					//获取第一个域的所有属性描述
					PropertyDescriptor proDec= propertyDescriptors[i];
					//获取这个域的setter方法
					Method setter= proDec.getWriteMethod();
					if (setter!=null && setter.isAnnotationPresent(MyResource.class)) {
						MyResource myResource= setter.getAnnotation(MyResource.class);
						
						//通过注解找bean注入
						if(myResource.name()!=null && !"".equals(myResource.name())){
							injectBean= Beansmap.get(myResource.name());
						}else{//注解找不到,那么通过属性的名称找
							injectBean= Beansmap.get(proDec.getName());
							//属性的名称找不到，那么通过属性的类型找
							if(injectBean==null){
								for(String key: Beansmap.keySet()){
									if (proDec.getPropertyType().isAssignableFrom(Beansmap.get(key).getClass())) {
										injectBean= Beansmap.get(key);
										break;
									}
								}
							}
						}
						setter.setAccessible(true);
						setter.invoke(object, injectBean);
					}
					
 				}
				
				
				
				
				/**
				 * 通过域注解
				 */
				Field[] fields= object.getClass().getDeclaredFields();
				for (int i = 0; i < fields.length; i++) {
					Field field=fields[i];
					if(field.isAnnotationPresent(MyResource.class)){
						MyResource myResource= field.getAnnotation(MyResource.class);
						Object value=null;
						if(myResource.name()!=null && !"".equals(myResource.name())){
							value=Beansmap.get(myResource.name());
						}else {
							value=Beansmap.get(field.getName());
							if (value==null) {
								for(String key: Beansmap.keySet()){
									if (field.getType().isAssignableFrom(Beansmap.get(key).getClass())) {
										value= Beansmap.get(key);
										break;
									}
								}
							}
						}
						field.setAccessible(true);
						field.set(object, value);
					}
				}
 			} catch (IntrospectionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
 	}
 	
 
 	
	public Object  getObject(String name) {
		return Beansmap.get(name);
	}

}
