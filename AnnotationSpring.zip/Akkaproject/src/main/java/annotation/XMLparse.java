package annotation;

 
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.XPath;
import org.dom4j.io.SAXReader;

import annotation.bean.BeanDefinition;
import annotation.bean.PropertyDefinition;

 
 
public class XMLparse {
	
	public static Map<String,BeanDefinition> read(String name){
		Map<String,BeanDefinition> classmap = new HashMap<String,BeanDefinition>();
		
		SAXReader saxReader= new SAXReader();
		
		/**
		 *  如果path以"/"开头，例如："/a.txt"，则从classpath的根下获取资源；
		 *	如果path不以"/"开头，例如"a.txt"，则从类所在的包路径下取资源。
		 */
		System.out.println(name+"\n"+XMLparse.class.getClassLoader().getResource(name));
		URL xmlpath= XMLparse.class.getClassLoader().getResource(name);
		Document document;
		try {
			document = saxReader.read(xmlpath);
	
			Map<String, String> map=new HashMap<String, String>();
			map.put("ns", "http://www.springframework.org/schema/beans");
			 
			XPath xpath=document.createXPath("//ns:beans/ns:bean");
			xpath.setNamespaceURIs(map);
			List<Element> beans= xpath.selectNodes(document); 
			for(int i=0;i<beans.size();i++){
				Element element=beans.get(i);
				String id = element.attributeValue("id");
				String classname= element.attributeValue("class");
				BeanDefinition beanDefinition =new BeanDefinition(id, classname);
				XPath Epath=element.createXPath("ns:property");
				Epath.setNamespaceURIs(map);
				List<Element> eList= Epath.selectNodes(element);
				for (Element element2 : eList) {
					String propertyname= element2.attributeValue("name");
					String ref= element2.attributeValue("ref");
					String value= element2.attributeValue("value");
					PropertyDefinition propertyDefinition=new PropertyDefinition(propertyname, ref, value);
					beanDefinition.getPropertyDefinitions().add(propertyDefinition);
				}
				classmap.put(id, beanDefinition);
			}	
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return classmap;
	}

}
